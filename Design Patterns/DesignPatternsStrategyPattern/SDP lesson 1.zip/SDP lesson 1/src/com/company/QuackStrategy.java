package com.company;

public interface QuackStrategy {
    void quack();
}
