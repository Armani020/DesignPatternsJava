package com.company;

public interface FlyStrategy {

    void fly();


}
